win = Titanium.UI.currentWindow;

var view1 = Ti.UI.createView({ backgroundColor:'#fff' });

// Create an ImageView.
var ImageView1 = Ti.UI.createImageView({
	image : '/img/01pigeons.png',
	width : 247,
	height :250,
});
ImageView1.addEventListener('load', function() {
});

// Add to the parent view.
view1.add(ImageView1);

var view2 = Ti.UI.createView({ backgroundColor:'#fff' });

var ImageView2 = Ti.UI.createImageView({
	image : '/img/02pigeons.png',
	width : 247,
	height :250,
});
ImageView1.addEventListener('load', function() {
});

// Add to the parent view.
view2.add(ImageView2);


var view3 = Ti.UI.createView({ backgroundColor:'#fff' });

var ImageView3 = Ti.UI.createImageView({
	image : '/img/03pigeons.png',
	width : 247,
	height :250,
});
ImageView3.addEventListener('load', function() {
});

// Add to the parent view.
view3.add(ImageView3);

var view4 = Ti.UI.createView({ backgroundColor:'#fff' });
var ImageView4 = Ti.UI.createImageView({
	image : '/img/04pigeons.png',
	width : 247,
	height :250,
});
ImageView4.addEventListener('load', function() {
});

// Add to the parent view.
view4.add(ImageView4);

var scrollableView = Ti.UI.createScrollableView({
  views:[view1,view2,view3,view4],
  showPagingControl:true,
  backgroundColor:"#fff"
});

win.add(scrollableView);