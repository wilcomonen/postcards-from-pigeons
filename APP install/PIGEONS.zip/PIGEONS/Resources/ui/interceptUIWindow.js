win = Titanium.UI.currentWindow;
