// create tab group
var pigeonsUIWindowtabGroup = Titanium.UI.createTabGroup();
 
//
// create base UI tab and root window
//
var pigeonsUIWindow = Titanium.UI.createWindow({
    title: 'PIGEONS',
    backgroundColor: '#fff',
    tintColor:"#fff",
    tabBarHidden: 'true',
    color:'#075eab'
});
var tab1 = Titanium.UI.createTab({
    icon: 'KS_nav_views.png',
    title: 'Overview',
    window: pigeonsUIWindow
});
  
 
 // Create a Button.
 var mypigeonsButton = Ti.UI.createButton({
     title : 'MY PIGEONS',
    top : 40,
	font:{fontSize:24, fontFamily:"TimesNewRomanPSMT", },
	color:'#075eab'
 });
 // Listen for click events.
 mypigeonsButton.addEventListener('click', function() {
    Titanium.UI.setBackgroundColor('#fff');
	var tabGroup = Ti.UI.createTabGroup();
 
	var win = Titanium.UI.createWindow({
		url:'/ui/myPigeonsUIWindow.js',
		title:"Pigeons",
		backgroundColor:"#fff",	
		tabBarHidden:true
	});
 
	var tab = Ti.UI.createTab({
    	title:"Pigeons",
    	window: win
	});
	var closeButton = Ti.UI.createButton({
        title:'Back',
	});		
	win.setLeftNavButton(closeButton);		
	
	closeButton.addEventListener('click',function(e) { 	
		tabGroup.close({animated:true});
	});
 
	tabGroup.addTab(tab);
	//tabGroup.open();
	tabGroup.open(tabGroup,{animated:true});	
 });
 // Add to the parent view.
 pigeonsUIWindow.add(mypigeonsButton);
 
 
  // Create a Button.
 var mymessagesButton = Ti.UI.createButton({
     title : 'MY MESSAGES',
    top : 100,
	font:{fontSize:24, fontFamily:"TimesNewRomanPSMT", },
	color:'#d0232b'
 });
 // Listen for click events.
 mymessagesButton.addEventListener('click', function() {
    Titanium.UI.setBackgroundColor('#fff');
	var tabGroup = Ti.UI.createTabGroup();
 
	var win = Titanium.UI.createWindow({
		url:'/ui/myMessagesUIWindow.js',
		title:"Pigeons",
		backgroundColor:"#fff",	
		tabBarHidden:true
	});
 
	var tab = Ti.UI.createTab({
    	title:"Pigeons",
    	window: win
	});
	var closeButton = Ti.UI.createButton({
        title:'Back',
	});		
	win.setLeftNavButton(closeButton);		
	
	closeButton.addEventListener('click',function(e) { 	
		tabGroup.close({animated:true});
	});
 
	tabGroup.addTab(tab);
	//tabGroup.open();
	tabGroup.open(tabGroup,{animated:true});
 });
 // Add to the parent view.
 pigeonsUIWindow.add(mymessagesButton);
 
 
   // Create a Button.
 var interceptButton = Ti.UI.createButton({
     title : 'INTERCEPT',
    top : 160,
	font:{fontSize:24, fontFamily:"TimesNewRomanPSMT", },
	color:'#d0232b'
 });
 // Listen for click events.
 interceptButton.addEventListener('click', function() {
    Titanium.UI.setBackgroundColor('#fff');
	var tabGroup = Ti.UI.createTabGroup();
 
	var win = Titanium.UI.createWindow({
		url:'/ui/interceptUIWindow.js',
		title:"Pigeons",
		backgroundColor:"#fff",	
		tabBarHidden:true
	});
 
	var tab = Ti.UI.createTab({
    	title:"Pigeons",
    	window: win
	});
	var closeButton = Ti.UI.createButton({
        title:'Back',
	});		
	win.setLeftNavButton(closeButton);		
	
	closeButton.addEventListener('click',function(e) { 	
		tabGroup.close({animated:true});
	});
 
	tabGroup.addTab(tab);
	//tabGroup.open();
	tabGroup.open(tabGroup,{animated:true});

 });
 // Add to the parent view.
 pigeonsUIWindow.add(interceptButton);


   // Create a Button.
 var settingsButton = Ti.UI.createButton({
     title : 'SETTINGS',
    top : 220,
	font:{fontSize:24, fontFamily:"TimesNewRomanPSMT", },
	color:'#d0232b'
 });
 // Listen for click events.
 settingsButton.addEventListener('click', function() {
    Titanium.UI.setBackgroundColor('#fff');
	var tabGroup = Ti.UI.createTabGroup();
 
	var win = Titanium.UI.createWindow({
		url:'/ui/settingsUIWindow.js',
		title:"Pigeons",
		backgroundColor:"#fff",	
		tabBarHidden:true
	});
 
	var tab = Ti.UI.createTab({
    	title:"Pigeons",
    	window: win
	});
	var closeButton = Ti.UI.createButton({
        title:'Back',
	});		
	win.setLeftNavButton(closeButton);		
	
	closeButton.addEventListener('click',function(e) { 	
		tabGroup.close({animated:true});
	});
 
	tabGroup.addTab(tab);
	//tabGroup.open();
	tabGroup.open(tabGroup,{animated:true});

 });
 // Add to the parent view.
 pigeonsUIWindow.add(settingsButton);
 
//
//  add tabs
//
pigeonsUIWindowtabGroup.addTab(tab1);
 
 
// open tab group
pigeonsUIWindowtabGroup.open();